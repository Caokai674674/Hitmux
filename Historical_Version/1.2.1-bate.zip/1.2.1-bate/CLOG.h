#ifndef CLOG_H
#define CLOG_H

#include <iostream>
#include <string>

using namespace std;

inline void clog_h(){
	cout<<"*****************************************************\n";
	cout<<"Hitmux 1.2.1-bate (C) 2024 CaoKai,All right reserved.\n";
	cout<<"1. Add game functions and use the command \"gmh\" to start.\n";
	cout<<"2. Improve prompts, warnings, and error Us.\n";
	cout<<"3. Fix some bugs.\n";
}
#endif
